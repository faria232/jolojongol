<?php
add_action( 'wp_enqueue_scripts', 'mountresort_child_enqueue_styles', 100 );
function mountresort_child_enqueue_styles() {
    wp_enqueue_style( 'mountresort-parent', get_theme_file_uri('/style.css') );
}
?>