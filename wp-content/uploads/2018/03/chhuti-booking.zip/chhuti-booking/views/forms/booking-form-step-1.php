<?php
// display booking for step 1
?>
<h2>Select a package</h2>
<?php
echo '<p>Date selected: '. date('j F, Y', $booking_date) .'</p>';
$html = [];
foreach($packages as $package) {
  $url = get_site_url() . '/wp-content/plugins/chhuti-booking/views/booking-form.php?date='. $booking_date .'&id='. $package->ID;
  $html[] = '<div>';
  $html[] = '<a href="'. $url .'">';
  $html[] = '<p>'. $package->post_title .'</p>';
  $html[] = '</a>';
  $html[] = '</div>';
}
echo join('', $html);
