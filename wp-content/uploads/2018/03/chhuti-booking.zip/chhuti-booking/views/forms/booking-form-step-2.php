<?php
// display rest of the booking forms
if($_SERVER['REQUEST_METHOD'] === 'POST') {                                                    
      $this->addBookingDetails();
} else {
?>

<form action="" method="post">

<input name="date" type="hidden" value="<?php echo $booking_date; ?>">
<input name="package_id" type="hidden" value="<?php echo $package_id; ?>">

<h2>Guest Info</h2>

<label for="name_first">First Name</label>
<input name="name_first" type="text">

<label for="name_last">Last Name</label>
<input name="name_last" type="text">

<label for="email">Email Address</label>
<input name="email" type="email">

<label for="phone">Phone</label>
<input name="phone" type="text">

<h2>Booking Info</h2>

<label for="count_adults">Adults</label>
<input name="count_adults" type="text">

<label for="count_children">Children</label>
<input name="count_children" type="text">

<label for="count_others">Drivers/Assistants</label>
<input name="count_others" type="text">


<h3>Group Type</h3>

<input name="group_type[]" type="checkbox" value="family">
<label for="group_type">Family</label>

<input name="group_type[]" type="checkbox" value="friends">
<label for="group_type">Friends</label>

<input name="group_type[]" type="checkbox" value="community">
<label for="group_type">Community</label>

<input name="group_type[]" type="checkbox" value="organization">
<label for="group_type">Organization</label>

<h3>Purpose</h3>

<input name="purpose[]" type="checkbox" value="leisure">
<label for="purpose">Leiusre</label>

<input name="purpose[]" type="checkbox" value="research">
<label for="purpose">Research</label>

<input name="purpose[]" type="checkbox" value="study">
<label for="purpose">Study</label>

<input name="purpose[]" type="checkbox" value="workshop">
<label for="purpose">Workshop</label>

<input type="submit" value="Book">

</form>
<?php
}
