<?php
// adding single transaction
include'/css/chhuti-admin.css';
?>
<form action="" method="post">
  <h3>Payment method</h3>
  <input class="font-18" type="hidden" name="booking_id" value="<?php echo $this->id; ?>">
  <label class="font-18" for="payment_method">Cash</label>
  <input type="radio" name="payment_method" value="cash">
  <label class="font-18" for="payment_method">Card</label>
  <input type="radio" name="payment_method" value="card">
   <p>
  <label class="font-18" for="payment_date">Payment Date</label>
  <input type="text" name="payment_date" value="<?php echo ($this->data['payment_date'])? $this->data['payment_date'] : ''; ?>">
    </p>

    <p>
  <label class="font-18" for="payment_amount">Payment Amount</label>
  <input type="text" name="payment_amount" value="<?php echo ($this->data['payment_amount'])? $this->data['payment_amount'] : ''; ?>">
    </p>

    <p>
  <label class="font-18" for="payment_received_by">Payment received by</label>
  <input type="text" name="payment_received_by" value="<?php echo ($this->data['payment_received_by'])? $this->data['payment_received_by'] : ''; ?>">
    </p>
    <p>
  <input class="add-pay-button" type="submit" value="Add Payment">
    </p>
</form>
