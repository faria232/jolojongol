<?php
// displaying payment confirmation page
?>
<h1>Payment added</h1>

<p><a href="<?php echo $url; ?>">Go back to payment details</a></p>

