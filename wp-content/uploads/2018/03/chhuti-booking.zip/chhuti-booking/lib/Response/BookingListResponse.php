<?php

namespace Chhuti\Plugins\Booking\Response;

class BookingListResponse()
{
  ;
}

