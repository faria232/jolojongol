<?php
namespace Chhuti\Plugins\Booking\Model;

use Chhuti\Plugins\Booking\DB;

class Booking
{
  /**
   * ID
   */
  private $id;

  /**
   * Calendar ID
   */
  private $calendarId;

  /**
   * date in timestamp
   */
  private $reservationDate;

  /**
   * date in timestamp
   */
  private $reservedOnDate;

  /**
   * json decoded details
   */
  private $bookingDetails;

  /**
   * keys used in booking details
   */
  private $bookingKeys = [
    'package',
    'guests_count',
    'count_adults',
    'count_children',
    'count_others',
    'booking_source',
    'primary_guest_name',
    'primary_guest_phone',
    'primary_guest_organisation',
    'primary_guest_email'
  ];

  private $db;

  /**
   * keys used in payment details
   */
  private $paymentKeys = [
    'payment_status',
    'payment_total',
    'payment_advance',
    'payment_due',
    'payments'
  ];

  /**
   * Keys used in transactions
   */
  private $transactionKeys = [
    'payment_amount',
    'payment_date',
    'bank_charge',
    'payment_method',
    'payment_received_by'
  ];

  /**
   * json decoded details
   */
  private $paymentDetails;

  /**
   * array to store all the transactions
   */
  private $transactions = [];

  const META_KEY_PRICE_ADULTS = 'package_price_for_adults';
  const META_KEY_PRICE_CHILDREN = 'package_price_for_children';
  const META_KEY_PRICE_OTHERS = 'package_price_for_others';
  const META_KEY_PACKAGE_STATUS = 'package_status';

  public function __construct($id = '')
  {
    $this->calendarId = 1;
    $this->db = new DB();

    if($id) {
      $this->id = $id;
      $this->extractBookingInfo();
    } else {
      $this->initialise();
    }
  }

  public function initialise()
  {
    $this->reservedOnDate = time();
  }

  public function extractBookingInfo()
  {
    $entry = $this->db->getBookingInfo($this->id);
    $this->reservationDate = strtotime($entry->reservation_date);
    $this->reservedOnDate = strtotime($entry->reserved_on_date);
    $this->bookingDetails = json_decode($entry->booking_details, true);
    $this->paymentDetails = json_decode($entry->payment_details, true);
    $this->transactions = $this->paymentDetails['payments'];
  }

  public function getId()
  {
    return $this->id;
  }

  public function getCalendarId()
  {
    return $this->calendarId;
  }

  public function getReservationDate()
  {
    return date('Y-m-d H:i:s', $this->reservationDate);
  }

  public function getReservedOnDate()
  {
    return date('Y-m-d H:i:s', $this->reservedOnDate);
  }

  public function getBookingDetails()
  {
    return $this->bookingDetails;
  }

  public function getPaymentDetails()
  {
    return $this->paymentDetails;
  }

  public function getAllTransactions()
  {
    return $this->transactions;
  }

  public function getTransaction($index)
  {
    if(count($this->transactions) === 0) {
      return false;
    }

    return $this->transactions[$index];
  }

  public function setCalendarId($id)
  {
    $this->calendarId = intval($id);
  }

  public function setReservationDate($date)
  {
    $this->reservationDate = intval($date);
  }

  public function setReservedOnDate($date)
  {
    $this->reservedOnDate = intval($date);
  }

  public function setBookingDetails(array $data)
  {
    foreach($data as $key => $value) {
      if(in_array($key, $this->bookingKeys)) {
        $this->bookingDetails[$key] = $value;
      }
    }
  }

  public function setPaymentDetails(array $data)
  {
    foreach($data as $key => $value) {
      if(in_array($key, $this->paymentKeys)) {
        $this->paymentDetails[$key] = $value;
      }
    }
  }

  public function addTransaction(array $data)
  {
    $transaction = [];
    foreach($data as $key => $value) {
      if(in_array($key, $this->transactionKeys)) {
        if($key == 'payment_date' && $value == '') {
          $transaction[$key] = date('Y-m-d H:i:s', time());
        } else {
          $transaction[$key] = $value;
        }
      }
    }
    $this->transactions[] = $transaction;
  }

  public function updateTransaction($index, array $data)
  {
    if($index == '' || !array_key_exists($index, $this->transactions)) {
      error_log('transaction index does not exists: '. $index);
      return false;
    }
    $array = [];
    foreach($data as $key => $value) {
      if(in_array($key, $this->transactionKeys)) {
        if($key == 'payment_date' && $value == '') {
          $array[$key] = date('Y-m-d H:i:s', time());
        } else {
          $array[$key] = $value;
        }
      }
    }
    $this->transactions[$index] = $array;
  }

  public function save()
  {
    $this->updateBalance();
    $this->updateStatus();
    $this->paymentDetails['payments'] = $this->transactions;
    if($this->validateModel()) {
      $insertId = $this->db->updateBookingInfo($this);
    }
    if($insertId) {
      $this->id = $insertId;
    }
  }

  public function getFutureBookingCounts()
  {
    $date_from = date('Y-m-d H:i:s', time());
    $date_to = date('Y-m-d H:i:s', strtotime('+31 days'));
    $bookings = $this->db->getFutureBookingCounts($date_from, $date_to);

    return $bookings;
  }

  private function updateBalance()
  {
    $payment_advance = 0;
    $payment_due = 0;

    foreach($this->transactions as $transaction) {
      $payment_advance += intval($transaction['payment_amount']);
    }

    $this->paymentDetails['payment_advance'] = $payment_advance;
  }

  private function updateStatus()
  {
    $payment_due = intval($this->paymentDetails['payment_total']) - intval($this->paymentDetails['payment_advance']);
    if(intval($this->paymentDetails['payment_total'])===0) {
      $this->paymentDetails['payment_status'] = 'pending';
    } elseif($payment_due > 0){
      $this->paymentDetails['payment_status'] = 'pending';
    } elseif($payment_due == 0 ) {
      $this->paymentDetails['payment_status'] = 'paid';
    } elseif($payment_due < 0 ){
      $this->paymentDetails['payment_status'] = 'overpaid';
    }

    $this->paymentDetails['payment_due'] = $payment_due;
  }

  private function validateModel()
  {
    $status = true;
    if($this->reservationDate == '') $status = false;
    if(empty($this->bookingDetails)) $status = false;
    if(empty($this->paymentDetails)) $status = false;

    return $status;
  }


}

