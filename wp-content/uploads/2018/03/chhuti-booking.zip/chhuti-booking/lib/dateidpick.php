<?php

    $db = mysql_connect("***", "***", "***") or die("Could not connect.");
    $link = mysql_select_db("***",$db);
